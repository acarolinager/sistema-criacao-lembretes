var formLembrete = document.getElementById('formLembrete');
var inputNomeLembrete = document.getElementById('nomeLembrete');
var inputData = document.getElementById('dataLembrete');
var mensagemErro = document.getElementById('msgError');
var tabelaTarefas = document.getElementById('table-tasks');

var listaTarefas = [];
// var lembreteTeste = {
//     nome: 'Lembrete Teste',
//     data: new Date(),
// };
// listaTarefas.push(lembreteTeste);

function removerLembrete(){
    var posicao = event.target.getAttribute('data-removeLembr');
    listaTarefas.splice(posicao, 1);
    atualizarTabela();
    console.log('Evento removido: ' + posicao);
}

//Atualizando a lista com os lembretes
function atualizarTabela(){
    if(listaTarefas.length === 0){
        tabelaTarefas.innerHTML = '<tr><td colspan="3">Nenhuma tarefa adicionada</td></tr>';
        return;
    }
    tabelaTarefas.innerHTML = '';

    for(var i = 0; i < listaTarefas.length; i ++){
        var teste = listaTarefas[i];
        var linha = document.createElement('tr');
        var celulaNome = document.createElement('td');
        var celulaData = document.createElement('td');
        var celulaExcluir = document.createElement('td');
        var btnExcluir = document.createElement('button');

        celulaNome.innerText = teste.nome;
        celulaData.innerText = teste.data;
        celulaExcluir.appendChild(btnExcluir);
        
        btnExcluir.innerHTML = '<i class="fa-regular fa-trash-can"></i>';
        btnExcluir.classList.add('btn');
        btnExcluir.classList.add('btn-outline-danger');
        btnExcluir.addEventListener('click', removerLembrete);
        btnExcluir.setAttribute('data-removeLembr', i);

        
        linha.appendChild(celulaNome);
        linha.appendChild(celulaData);
        linha.appendChild(celulaExcluir);
        tabelaTarefas.appendChild(linha); 
    }
}

function lembreteValido(nomeLembrete, dataLembrete){ 
    var validacao = true;
    var erro = '';

    //Validando se nome do lembrete esta vazio
    if(nomeLembrete.trim().length === 0) { 
        erro = 'O nome do lembrete é obrigatório.';
        inputNomeLembrete.classList.add('is-invalid');
        validacao = false; 
    } else {
        inputNomeLembrete.classList.remove('is-invalid');
    }

    //Validação das datas
    var timeDtLembrete = Date.parse(dataLembrete);
    var timeDtAtual = (new Date()).getTime();
    if(isNaN(timeDtLembrete) || timeDtLembrete < timeDtAtual){
        if(erro.length > 0){
            erro += '<br>'
        }
        erro += 'Insira uma data válida!';
        inputData.classList.add('is-invalid');
        validacao = false;
    } else {
        inputData.classList.remove('is-invalid');
    }

    //Mensagem de erro
    if(!validacao){
        mensagemErro.innerHTML = erro;
        mensagemErro.classList.remove('d-none');
    } else {
        mensagemErro.classList.add('d-none');
    }
    return validacao;
}

function salvarLembrete(event){
    event.preventDefault();
    var nomeLembrete = inputNomeLembrete.value;
    var dataLembrete = inputData.value;

    if(lembreteValido(nomeLembrete, dataLembrete)){
        console.log('Lembrete valido');
        listaTarefas.push({
            nome: nomeLembrete,
            data: new Date(dataLembrete),
        });
        atualizarTabela();
        limparForm();
    } else {
        console.log('Lembrete inválido');
    }
}

function limparForm(){
    document.getElementById('formLembrete').reset();
    mensagemErro.classList.add('d-none');
    inputData.classList.remove('is-invalid');
    inputNomeLembrete.classList.remove('is-invalid');
}

formLembrete.addEventListener('submit', salvarLembrete);
window.addEventListener('load', atualizarTabela);
